const Result = () => {
  return <div>Result Page</div>;
};
export default Result;
