import { useState } from "react";
import Categories from "../../Data/Categories";
import "./Home.css";
import { MenuItem, TextField, Button } from "@mui/material";
import { useNavigate } from "react-router-dom";
import ErrorMessage from "../../components/ErrorMessage/ErrorMessage";

const Home = ({ fetchQuestions }) => {
  const [category, setCategory] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [error, setError] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = () => {
    if (!category || !difficulty) {
      setError(true);
      return;
    } else {
      setError(false);
      fetchQuestions(category, difficulty);
      navigate("/quiz");
    }
  };
  return (
    <div className="content">
      <div className="settings">
        <span style={{ fontSize: 30 }}>Start</span>
        <div className="settings__select">
          {error && <ErrorMessage>Välj alla alternativ</ErrorMessage>}
          <TextField
            select
            label="Välj Kategori"
            variant="outlined"
            style={{ marginBottom: 30 }}
            onChange={(e) => setCategory(e.target.value)}
            value={category}
          >
            {Categories.map((cat) => (
              <MenuItem key={cat.category} value={cat.value}>
                {cat.category}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            select
            label="Välj Svårighetsgrad"
            vatiant="outlined"
            style={{ marginBottom: 30 }}
            onChange={(e) => setDifficulty(e.target.value)}
            value={difficulty}
          >
            <MenuItem key="Easy" value="easy">
              Lätt
            </MenuItem>
            <MenuItem key="Medium" value="medium">
              Medium
            </MenuItem>
            <MenuItem key="Hard" value="hard">
              Svårt
            </MenuItem>
          </TextField>
          <Button
            vatiant="container"
            color="primary"
            size="Large"
            onClick={handleSubmit}
          >
            Starta Quiz
          </Button>
        </div>
      </div>
    </div>
  );
};
export default Home;
