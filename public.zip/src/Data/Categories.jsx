const Categories = [
  { category: "Films", value: 11 },
  { category: "Music", value: 12 },
  { category: "Mythology", value: 20 },
  { category: "Comics", value: 29 },
];

export default Categories;
