import axios from "axios";
import { Routes, Route } from "react-router-dom";
import Header from "./components/Header/Header";
import "./App.css";
import Home from "./Pages/Home/Home";
import Quiz from "./Pages/Quiz/Quiz";
import Result from "./Pages/Result/Result";
import { useState } from "react";

function App() {
  const [questions, setQuestions] = useState();
  const [score, setScore] = useState(0);
  const fetchQuestions = async (category = "", difficulty = "") => {
    const { data } = await axios.get(
      `https://opentdb.com/api.php?amount=10${
        category && `&category=${category}`
      }${difficulty && `&difficulty=${difficulty}`}&type=multiple`
    );

    setQuestions(data.results);
  };

  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Home fetchQuestions={fetchQuestions} />} />

        <Route
          path="/quiz"
          element={
            <Quiz
              questions={questions}
              score={score}
              setScore={setScore}
              setQuestions={setQuestions}
            />
          }
        />

        <Route path="/result" element={<Result />} />
      </Routes>
    </>
  );
}

export default App;
