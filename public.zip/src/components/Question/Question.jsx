import { useState } from "react";

const Question = ({
  currQues,
  setCurrQues,
  questions,
  options,
  correct,
  setScore,
  score,
  setQuestions,
}) => {
  const [selected, setSelected] = useState;

  return (
    <div>
      <h1>Fråga</h1>
      <div classname="SingleQuestion">
        <h2>{questions[currQues].question}</h2>
      </div>
    </div>
  );
};
export default Question;
